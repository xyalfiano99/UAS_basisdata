<x-filament-panels::page>
    <h2 class="text-2xl">{{ $record->name }}</h2>
</x-filament-panels::page>
